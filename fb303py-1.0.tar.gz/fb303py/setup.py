from distutils.core import setup

setup(name='fb303',
      version='1.0',
      packages=['fb303', 'fb303_scripts'],
      )


