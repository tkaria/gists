This is a sample of using Boost/asio together with Google Protocol buffers 
(protobuf). It was tested on Linux (Ubuntu), but since it's standard C++
and uses only portable libraries, it should work on any platform. boost and
protobuf should be installed. A Makefile is provided for Linux.

The code is in the public domain. See COPYING for more details.

Eli Bendersky (eliben@gmail.com)

