BLPAPI Open Download Package

The BLPAPI Open download package consists of the following sets:
- BLPAPI-Perl.tar.gz		Perl wrapper for Linux and Solaris and Windows
- BLPAPI-Linux.tar.gz		Linux package with C, C++, Java
- BLPAPI-SunOS.tar.gz		Solaris package with C, C++, Java
- BLPAPI-Windows.zip		Windows package with C, C++, Java, .NET, COM

Each set contains complete examples.  Directory structure for the different platforms:

Linux and Solaris:  Directory APIv3/<language>
  include	header files
  examples	source file for examples
  doc		documentation
  Linux		Compiled examples and libraries
  Solaris	Compiled examples and libraries

Windows: Directory C:\blp\MBpipe\APIv3\<language>
Each of the sub directories contains examples and libraries for each language.

Perl: Directory Bloomberg-API-<version>
	

