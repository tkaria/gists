This C file (driver_entry.c) is used when building a dynamic library for
the Windows kernel.  It exists to work around one of the limitations of
that build environment.  It is not used  by any other build; just ignore it.

