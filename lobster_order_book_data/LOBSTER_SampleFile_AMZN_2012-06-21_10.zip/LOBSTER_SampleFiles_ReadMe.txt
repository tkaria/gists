=========================================================================

LOBSTER 
Limit Order Book System - The Efficient Reconstructor

http://LOBSTER.wiwi.hu-berlin.de


=========================================================================

Sample Files Readme


	I.) 	Data Structure
	II.) 	Matlab/R Help

=========================================================================

I.) Data Structure:
-------------------

LOBSTER generates a 'message' and an 'orderbook' file for each active 
trading day. The message file contains indicators for the type of event 
causing an update of the limit order book time stamped to seconds after 
midnight with decimal precision of at least milliseconds and up to 
nanoseconds depending on the requested period. The orderbook file 
contains the evolution of the order book up to the requested level.


	Message File:		(Matrix of size: (Nx6))
	-------------	
			
	Name: 	TICKER_Year-Month-Day_StarTime_EndTime_message_LEVEL.csv 	
		
		StartTime and EndTime give the theoretical beginning 
		and end time of the output file in milliseconds after 		
		mid night.


	Columns:
	
	    1.) Time: 		
				Seconds after midnight with decimal 
				precision of at least milliseconds 
				and up to nanoseconds depending on 
				the requested period
	    2.) Type:
				1: Submission new limit order
				2: Cancellation (Partial deletion 
				   limit order)
				3: Deletion (Total deletion limit order)
				4: Execution (Against visible limit order)			   	   
				5: Execution (Against hidden limit order)			   	   
				100: Other (Unknown)
	    3.) Order ID: 	
				Unique order reference number 
				(assigned in order flow)
	    4.) Size: 		
				Number of shares
	    5.) Price: 		
				Dollar price times 10000 
				(i.e. A stock price of $91.14 is given 
				by 911400)
	    6.) Direction:
				-1: Sell limit order
				1: Buy limit order
				
				Note: 
				Execution of a sell (buy) limit
				order corresponds to a buyer (seller) 
				initiated trade, i.e. Buy (Sell) trade.

						
	Orderbook File:		(Matrix of size: (Nx4*NumberOfLevels)						
	---------------
	
	Name: 	TICKER_Year-Month-Day_StartTime_EndTime_orderbook_LEVEL.csv
	
	Columns:
	
 	    1.) Ask Price 1: 	Level 1 Ask Price (Best Ask)
	    2.) Ask Size 1: 	Level 1 Ask Volume (Best Ask Volume)
	    3.) Bid Price 1: 	Level 1 Bid Price (Best Bid)
	    4.) Bid Size 1: 	Level 1 Bid Volume (Best Bid Volume)
	    5.) Ask Price 2: 	Level 2 Ask Price (Best Ask)
	    ...
	
	Note: 	 
	
	The term level refers to occupied price levels. This implies 
	that the difference between two levels in the LOBSTER output 
	is not necessarily the minimum ticks size.

	When the selected number of levels exceeds the number of levels 
	available, the extra bid and/or ask prices are set to 
	-9999999999 and 99999999, respectively. 
	The Corresponding volumes are set to 0. 
	
=========================================================================


II.) Matlab/R Code:
-------------------

	We have prepared small demo Matlab and R codes to help you get 
	started with the LOBSTER data.

	You can find the code at: 	http://LOBSTER.wiwi.hu-berlin.de 	
			


=========================================================================

Any questions? Just contact us at http://LOBSTER.wiwi.hu-berlin.de 

=========================================================================